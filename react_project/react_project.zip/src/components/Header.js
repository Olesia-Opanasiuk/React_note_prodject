import { NavLink } from "react-router-dom";

function Header(props) {
    return (
        <div>
            <nav >
                <ul className="header-nav">
                    <li><NavLink exact="true" className="" to="/" >Home</NavLink></li>
                    <li><NavLink className="" to="/note" >Note</NavLink></li>
                    <li><NavLink className="" to="/create" >Create</NavLink></li>
                    <li><NavLink className="" to="/about" >About</NavLink></li>
                </ul>
            </nav>
        </div>
    );
}

export default Header;
