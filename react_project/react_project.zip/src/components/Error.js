
function Error(props) {
    console.log(props);
    const currentUrl = window.location;
    console.log(currentUrl);
    return (
        <div>
            <div className="wrapper" style={{
                backgroundImage: `url(${props.data.error.srcImg})`,
                backgroundRepeat: "no-repeat",
                backgroundSize: "100%",
            }}>
                <div>404</div>
            </div>
        </div>
    );
}

export default Error;
