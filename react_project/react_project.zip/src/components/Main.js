
function Main(props) {
    const currentUrl = window.location;
    console.log(currentUrl);
    return (
        <div className="container" >
            <div className="wrapper" style={{
                backgroundImage: `url(${props.data.main.srcImg})`,
                backgroundRepeat: "no-repeat",
                backgroundSize: "100%",
            }} >
                <div className="link">
                    <a href="/create">Cоздать Note</a>
                </div>
                <div className="link">
                    <a href="/note">Просмотреть Note</a>
                </div>
            </div>
        </div >
    );
}

export default Main;
